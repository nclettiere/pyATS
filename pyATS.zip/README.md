# pyATS
Blender addon for ATS module

Requires installation of https://kieranwynn.github.io/pyquaternion/ inside Blender's bundled python.
